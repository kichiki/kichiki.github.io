#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifdef USE_DMEDIA
#include <dmedia/cl.h>

int GetJPEGSizeEstimate(int width,int height){ 
  CLhandle cmp;
  int compressedBufferSize;
  /* lets do it */
  clOpenCompressor(CL_JPEG_SOFTWARE, &cmp); /* this might be costly op */
  clSetParam(cmp, CL_IMAGE_WIDTH,width);
  clSetParam(cmp, CL_IMAGE_HEIGHT,height);
  clSetParam(cmp, CL_FORMAT, CL_FORMAT_BGR);
  compressedBufferSize=clGetParam(cmp,CL_COMPRESSED_BUFFER_SIZE);
  clCloseCompressor(cmp);
  return compressedBufferSize;
}
void SwapColorRGB(unsigned char *image,int npixels){
  register int i;
  for(i=0;i<npixels;i++,image+=3){
    unsigned char tmp=image[0];
    image[0]=image[3];
    image[3]=tmp;
  }
}
int WriteJPEGToMemoryRGB(int width,int height,void *inbuffer,float compressionRatio,char *compressedBuffer,int compressedBufferSize){
   unsigned char *xbgr_image= (unsigned char*)inbuffer;
   SwapColorRGB(xbgr_image,nx*ny);
  /* lets do it:  Open the compressor */
  clOpenCompressor(CL_JPEG_SOFTWARE, &cmp); /* this might be costly op (software JPEG) */
  /* use CL_JPEG_COSMO to do harware assisted compression where available */
  clSetParam(cmp, CL_IMAGE_WIDTH,width);
  clSetParam(cmp, CL_IMAGE_HEIGHT,height);
  clSetParam(cmp, CL_COMPRESSION_RATIO,CL_TypeIsInt(compressionRatio));
  /* we'll just use 0xBBGGRR 24-bit word format to save a little space
     need to convert RGB to BGR somewhere...  I don't know why it doesn't
     support RGB interleaving */
  clSetParam(cmp, CL_FORMAT, CL_FORMAT_BGR);
  clCompress(cmp,1,xbgr_image,&compressedBufferSize,compressedBuffer);
  clCloseCompressor(cmp);
  SwapColorRGB(xbgr_image,nx*ny);
  return compressedBufferSize;
}

int WriteJPEGToFileRGB(int nx,int ny,void *data,float compressionRatio,char *filename){
  char *compressedBuffer;
  int clen;
  FILE *jpeg = fopen(filename,"w");
  if(jpeg==NULL){
    printf("WriteJPEG : error, could not open file [%s] for writing\n",filename);
    return 0;
  }
  clen=GetJPEGsizeEstimate();
  compressedBuffer =(char *)malloc(clen);
  clen=WriteJPEGtoMemoryRGB(nx,ny,data,compressionRatio,compressedBuffer,clen);
  fwrite(compressedBuffer,1,clen,jpeg);
  fclose(jpeg);
  free(compressedBuffer);
  return 1;
}

#else
/* Put the libJPEG stuff here */

#endif
