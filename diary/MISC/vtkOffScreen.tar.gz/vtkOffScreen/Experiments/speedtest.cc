#include <stdio.h>
#include <stdlib.h>
#include "Timer.hh"
#include <unistd.h>
#include "vtkOpenGLOffscreenRenderWindow.h"
#include <vtk.h>
int main(int argc,char *argv[]){
  Timer tfbread,tffbread,tcompress;
  #ifdef OFFSCREEN
  vtkOpenGLOffscreenRenderWindow *renWin= vtkOpenGLOffscreenRenderWindow::New();   
  int width = 512;
  int height = 512;
  renWin->SetSize(width,height);
#else
  vtkRenderWindow *renWin = vtkRenderWindow::New();
#endif
  // renWin->DebugOn();
  vtkRenderer *ren1;
  vtkSphereSource *sphere;
  vtkPolyDataMapper *map;
  vtkActor *aSphere;
  // You must render everything in immediate mode when
  // you do offscreen rendering in order to get consistent
  // results.
  vtkMapper::GlobalImmediateModeRenderingOn();
  // create a window, renderer and interactor
  ren1 = vtkRenderer::New();
  // ren1->DebugOn();
  renWin->AddRenderer(ren1);
  // create sphere geometry
  sphere = vtkSphereSource::New();
  sphere->SetRadius(1.0);
  sphere->SetThetaResolution(18);
  sphere->SetPhiResolution(18);
  // map to graphics library
  map = vtkPolyDataMapper::New();
  map->SetInput(sphere->GetOutput());
  // actor coordinates geometry, properties, transformation
  aSphere = vtkActor::New();
  aSphere->SetMapper(map);
  aSphere->GetProperty()->SetColor(0,0,1); // sphere color blue
  ren1->AddActor(aSphere);
  ren1->SetBackground(1,1,1); // Background color white
  // Render an image; since no lights/cameras specified, created automatically
  renWin->Render();
  //renWin->WriteImage("sphere.ppm");
  //renWin->WriteJPEG("sphere.jpeg");
  unsigned int *xbgr_image = new unsigned int[width*height];
  tfbread.stop();
  tfbread.reset();
  tfbread.start();
  for(int i=0;i<1000;i++){
    renWin->fbReadPixels(0,0,width,height,GL_ABGR_EXT,GL_UNSIGNED_BYTE,xbgr_image);
  }
  
  tffbread.stop();
  tffbread.start();
  for(int i=0;i<1000;i++){
    renWin->fbReadPixels(0,0,width,height,GL_ABGR_EXT,GL_FUNSIGNED_BYTE,xbgr_image);
  }
  tffbread.stop();
  
  // compression timing
  CLhandle cmp;
  int compressedBufferSize;
   // lets do it
  clOpenCompressor(CL_JPEG_SOFTWARE, &cmp); // this might be costly op (software JPEG)
  // use CL_JPEG_COSMO to do harware assisted compression where available
  clSetParam(cmp, CL_IMAGE_WIDTH,width);
  clSetParam(cmp, CL_IMAGE_HEIGHT,height);
  clSetParam(cmp, CL_FORMAT, CL_FORMAT_XBGR);
  compressedBufferSize = clGetParam(cmp,CL_COMPRESSED_BUFFER_SIZE);
  // fbReadPixels(0,0,width,height,GL_ABGR_EXT,GL_UNSIGNED_BYTE,xbgr_image);
  // compress from xbgr_image source to compressedBuffer destination
  tcompress.stop();
  tcompress.reset();
  tcompress.start();
  for(int i=0;i<1000;i++){
    clCompress(cmp,1,xbgr_image,&compressedBufferSize,compressedBuffer);
  }
  tcompress.stop();
  clCloseCompressor(cmp);
  
  tfbread.print("fbread timing : ");
  tffbread.print("ffbread timing : ");
  tcompress.print("tcompress timing : ");
  puts("done");
}
