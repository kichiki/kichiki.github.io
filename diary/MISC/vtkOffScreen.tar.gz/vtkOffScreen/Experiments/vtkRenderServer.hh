
/*
  This is used exclusively on SGI systems where the PBUFFER hardware
offscreen renderer apparently cannot be used by more than one process
at a time.  Its a first-come-first serve affair.  So an arbitrator must
be used to share the framebuffer among multiple processors and multiple
users.  Perhaps it should even offer the framebuffer up to remote 
processes through a socket connection?

Anyways, this requires that the data to be rendered be copied into SGI 
shared memory so that the renderserver can process it and pass back
the resulting framebuffer image.

would be nice if you could declare data thread-shareable through 
so me sort of ACL publication methodafter it has been allocated
 
  */

class vtkPbufferRenderWindow {
public:
  
};

class vtkPbufferRenderServer {
public:
  
};


/*

Tomorrow
H5reader for FlexIO
IEEEIO 64bit datasets extension?
Parallel benchmarks
Fixup HDFreader
Add Threader checks for sproc/pthread incompatability

================================

Need a geometry decimator that takes the viewpoint & frustrum and decimates a geometry to 

* remove non-visible polygons
* merge polygons that have a low crease angle and would otherwise be subpixel in resolution and depend on gouraud shading to smooth their angle away.
    Option to merge polygons and replace with geometry that fits within error bounds defined by the original geometry rather than rather than being topologically identical. This is re-triangulation within error bounds weighted by maximum projected size of the triangle and degree of local curvature (as defined by local error bounds).  Error bounds can be constructed based on distance from a plane defined by neighboring triangles.  Need to create a quick-reference vertex-neighbor-pointer structure to accelerate rapid search for neighboring vertices.  So this would be a crawling re-mesher for geometry.

    * Compute actual z-depth using full matrix transform and pre-stack polygons in order to perform visibility culling.  This is very view-dependent so it needs to be recomputed as view changes.  The previously mentioned methods only require recomputation when the scale of the object changes.


    * recursive remesher uses only local properties of the mesh and only replaces polygons with edge-constrained transformations. (basically point constrained... just choose which points to drop based on local curvature at a particular point and then rework the local connectivity to account for the dropped point.  First rank points for remeshing based on local curvature (done only once on initial mesh) and then try to drop top-ranked points which are independent from one-another.  Must make this view-dependent.

struct PointLink {
PointLink *neighbors;
int nneighbors;
float p[3]; // position
};

Yo John... need to fix the UCD convertor to deal with integers
Need to fix file format to use integer refinement more rationally.

 */
