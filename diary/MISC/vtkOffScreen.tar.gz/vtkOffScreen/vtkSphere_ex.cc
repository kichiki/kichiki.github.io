#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "vtkOpenGLOffscreenRenderWindow.h"
#include <vtkRenderer.h>
#include <vtkSphereSource.h>
#include <vtkActor.h>
#include <vtkPolyDataMapper.h>
//#include <vtk.h>
/*
#ifdef OFFSCREEN 
#undef OFFSCREEN
#endif
*/

/********************************************************************
Draw a vtkSphere using offscreen rendering and write to a ppm file
called "sphere.ppm".
*********************************************************************/
main (){
#ifdef OFFSCREEN
  vtkOpenGLOffscreenRenderWindow *renWin= vtkOpenGLOffscreenRenderWindow::New(); 
  renWin->SetSize(512,512);
#else
  vtkRenderWindow *renWin = vtkRenderWindow::New();
#endif
  // renWin->DebugOn();
  vtkRenderer *ren1;
  vtkSphereSource *sphere;
  vtkPolyDataMapper *map;
  vtkActor *aSphere;
  // You must render everything in immediate mode when
  // you do offscreen rendering in order to get consistent
  // results.
  vtkMapper::GlobalImmediateModeRenderingOn();
  // create a window, renderer and interactor
  ren1 = vtkRenderer::New();
  // ren1->DebugOn();
  renWin->AddRenderer(ren1);
  // create sphere geometry
  sphere = vtkSphereSource::New();
  sphere->SetRadius(1.0);
  sphere->SetThetaResolution(18);
  sphere->SetPhiResolution(18);
  // map to graphics library
  map = vtkPolyDataMapper::New();
  map->SetInput(sphere->GetOutput());
  // actor coordinates geometry, properties, transformation
  aSphere = vtkActor::New();
  aSphere->SetMapper(map);
  aSphere->GetProperty()->SetColor(0,0,1); // sphere color blue
  ren1->AddActor(aSphere);
  ren1->SetBackground(1,1,1); // Background color white
  // Render an image; since no lights/cameras specified, created automatically
  renWin->Render();
  puts("WriteImage");
  // sleep(6);
#ifndef OFFSCREEN
  sleep(5);
#else
  renWin->WriteImage("sphere.ppm");
#ifdef USE_DMEDIA
  renWin->WriteJPEG("sphere.jpeg");
#endif
#endif
  puts("done");
}
