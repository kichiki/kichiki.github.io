#define WAON_VERSION "0.10"
