#define WAON_VERSION "0.2"
